export interface Schema {
    id: string;
    name: string;
    modelCount: number;
}